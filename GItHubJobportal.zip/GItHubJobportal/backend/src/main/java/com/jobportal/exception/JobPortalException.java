package com.jobportal.exception;

public class JobPortalException extends Exception {

	private static final long serialVersionUID = 1L;
	 public JobPortalException(String message){
	        super(message);
	    }

}
