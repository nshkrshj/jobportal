package com.jobportal.dto;

public enum JobStatus {
	ACTIVE, CLOSED, DRAFT         
}
