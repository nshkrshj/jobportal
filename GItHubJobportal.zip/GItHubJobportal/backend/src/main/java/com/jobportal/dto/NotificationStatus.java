package com.jobportal.dto;

public enum NotificationStatus {
	READ, UNREAD
}
